<template>
	<view>
		<jy-navbar :title="$t('personal.aboutUs')"></jy-navbar>
		关于我们
	</view>
</template>

<script>
	export default {
		data() {
			return {
				
			}
		},
		methods: {
			
		}
	}
</script>

<style>

</style>
