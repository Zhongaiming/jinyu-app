<template>
	<view class="xls-order-detail">
		<jy-navbar title="退款详情"></jy-navbar>
		<view class="xls-main-wrapper">
			<view class="xls-box-style">
				
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				
			}
		},
		methods: {
			
		}
	}
</script>

<style scoped lang="scss">
	@import 'index.scss';
</style>